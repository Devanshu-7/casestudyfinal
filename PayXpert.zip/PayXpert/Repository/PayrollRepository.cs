﻿using PayXpert.Exceptions;
using PayXpert.Models;
using PayXpert.Utility;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayXpert.Repository
{
    public class PayrollRepository : IPayrollService
    {
        //Add Payroll to DB
        void IPayrollService.GeneratePayroll(int employeeId, DateTime startDate, DateTime endDate, decimal basicSalary, decimal deductions, decimal overtimePay)
        {
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                // Calculate net salary
                decimal netSalary = basicSalary + overtimePay - deductions;

                string insertQuery = @"
                                        INSERT INTO Payroll (EmployeeId, PayPeriodStartDate, PayPeriodEndDate, BasicSalary, OvertimePay, Deductions, NetSalary)
                                        VALUES (@EmployeeId, @StartDate, @EndDate, @BasicSalary, @OvertimePay, @Deductions, @NetSalary);
                                        SELECT SCOPE_IDENTITY();";
               

                using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                {
                    // Parameters
                    insertCommand.Parameters.AddWithValue("@EmployeeId", employeeId);
                    insertCommand.Parameters.AddWithValue("@StartDate", startDate);
                    insertCommand.Parameters.AddWithValue("@EndDate", endDate);
                    insertCommand.Parameters.AddWithValue("@BasicSalary", basicSalary);
                    insertCommand.Parameters.AddWithValue("@OvertimePay", overtimePay);
                    insertCommand.Parameters.AddWithValue("@Deductions", deductions);
                    insertCommand.Parameters.AddWithValue("@NetSalary", netSalary);

                    connection.Open();
                    
                    int insertedPayrollId = Convert.ToInt32(insertCommand.ExecuteScalar());

                    if (insertedPayrollId > 0)
                    {
                        Console.WriteLine("Payroll generated and added to the database successfully. Payroll ID: " + insertedPayrollId);
                    }
                    else
                    {
                        throw new PayrollGenerationException("Error: Generating payroll for employee.");
                    }
                }
            }
        }

        PayRoll IPayrollService.GetPayrollById(int payrollId)
        {
            PayRoll payRoll = null;
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "SELECT * FROM Payroll WHERE PayrollId = @PayrollId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PayrollId", payrollId);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        payRoll = new PayRoll
                        {
                            PayrollID = reader.GetInt32(reader.GetOrdinal("PayrollId")),
                            EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeId")),
                            PayPeriodStartDate = reader.GetDateTime(reader.GetOrdinal("PayPeriodStartDate")),
                            PayPeriodEndDate = reader.GetDateTime(reader.GetOrdinal("PayPeriodEndDate")),
                            BasicSalary = reader.GetDecimal(reader.GetOrdinal("BasicSalary")),
                            OvertimePay = reader.GetDecimal(reader.GetOrdinal("OvertimePay")),
                            Deductions = reader.GetDecimal(reader.GetOrdinal("Deductions")),
                            NetSalary = reader.GetDecimal(reader.GetOrdinal("NetSalary"))
                        };
                    }
                }
            }
            return payRoll;
        }
  

        List<PayRoll> IPayrollService.GetPayrollsForEmployee(int employeeId)
        {
            List<PayRoll> payRollList = new List<PayRoll> { };

            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "SELECT * FROM Payroll WHERE EmployeeId = @EmployeeId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmployeeId", employeeId);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        //Add data from DB to Payroll Object
                        PayRoll payroll = new PayRoll
                        {
                            PayrollID = reader.GetInt32(reader.GetOrdinal("PayrollId")),
                            EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeId")),
                            PayPeriodStartDate = reader.GetDateTime(reader.GetOrdinal("PayPeriodStartDate")),
                            PayPeriodEndDate = reader.GetDateTime(reader.GetOrdinal("PayPeriodEndDate")),
                            BasicSalary = reader.GetDecimal(reader.GetOrdinal("BasicSalary")),
                            OvertimePay = reader.GetDecimal(reader.GetOrdinal("OvertimePay")),
                            Deductions = reader.GetDecimal(reader.GetOrdinal("Deductions")),
                            NetSalary = reader.GetDecimal(reader.GetOrdinal("NetSalary"))
                        };

                        payRollList.Add(payroll);
                    }
                }
            }
            PrintPayroll(payRollList);
            return payRollList;
        }

        List<PayRoll> IPayrollService.GetPayrollsForPeriod(DateTime startDate, DateTime endDate)
        {
            List<PayRoll> payrollList = new List<PayRoll>();
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "SELECT * FROM Payroll WHERE PayPeriodStartDate >= @StartDate AND PayPeriodEndDate <= @EndDate";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StartDate", startDate);
                    command.Parameters.AddWithValue("@EndDate", endDate);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        PayRoll payroll = new PayRoll
                        {
                            PayrollID = reader.GetInt32(reader.GetOrdinal("PayrollId")),
                            EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeId")),
                            PayPeriodStartDate = reader.GetDateTime(reader.GetOrdinal("PayPeriodStartDate")),
                            PayPeriodEndDate = reader.GetDateTime(reader.GetOrdinal("PayPeriodEndDate")),
                            BasicSalary = reader.GetDecimal(reader.GetOrdinal("BasicSalary")),
                            OvertimePay = reader.GetDecimal(reader.GetOrdinal("OvertimePay")),
                            Deductions = reader.GetDecimal(reader.GetOrdinal("Deductions")),
                            NetSalary = reader.GetDecimal(reader.GetOrdinal("NetSalary"))
                        };

                        payrollList.Add(payroll);
                    }
                }
            }
            PrintPayroll(payrollList);
            return payrollList;
        }

        public void PrintPayroll(List<PayRoll> payrollList)
        {
            if (payrollList == null || payrollList.Count == 0)
            {
                throw new PayrollGenerationException("Error generating payroll for employee.");
            }

            Console.WriteLine("Payroll Details:");
            foreach (var payroll in payrollList)
            {
                Console.WriteLine($"Payroll ID: {payroll.PayrollID} ||| Employee ID: {payroll.EmployeeID} ||| Pay Period Start Date: {payroll.PayPeriodStartDate.ToShortDateString()} ||| Pay Period End Date: {payroll.PayPeriodEndDate.ToShortDateString()} ||| Basic Salary: {payroll.BasicSalary} ||| Overtime Pay: {payroll.OvertimePay} ||| Deductions: {payroll.Deductions} | Net Salary: {payroll.NetSalary}");
            }

        }
    }
}
