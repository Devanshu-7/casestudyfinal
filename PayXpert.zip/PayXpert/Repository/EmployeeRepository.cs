﻿using PayXpert.Exceptions;
using PayXpert.Models;
using PayXpert.Utility;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayXpert.Repository
{
    public class EmployeeRepository : IEmployeeService
    {
        //Add employee details to DB
        int IEmployeeService.AddEmployee(Employee employeeData)
        {
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = @"
                                INSERT INTO Employee (FirstName, LastName, DateOfBirth,Gender, Gmail, PhoneNumber, Address, Position, JoiningDate, TerminationDate)
                                VALUES (@FirstName, @LastName, @DateOfBirth, @Gender, @Email, @PhoneNumber, @Address, @Position, @JoiningDate, @TerminationDate);
                                SELECT SCOPE_IDENTITY();";

                SqlCommand command = new SqlCommand(query, connection);

                // Add parameters
                command.Parameters.AddWithValue("@FirstName", employeeData.FirstName);
                command.Parameters.AddWithValue("@LastName", employeeData.LastName);
                command.Parameters.AddWithValue("@DateOfBirth", employeeData.DateOfBirth);
                command.Parameters.AddWithValue("@Gender", employeeData.Gender);
                command.Parameters.AddWithValue("@Email", employeeData.Email);
                command.Parameters.AddWithValue("@PhoneNumber", employeeData.PhoneNumber);
                command.Parameters.AddWithValue("@Address", employeeData.Address);
                command.Parameters.AddWithValue("@Position", employeeData.Position);
                command.Parameters.AddWithValue("@JoiningDate", employeeData.JoiningDate);
                command.Parameters.AddWithValue("@TerminationDate", employeeData.TerminationDate.HasValue ? (object)employeeData.TerminationDate.Value : DBNull.Value); //handle null
               

                connection.Open();
               
                int insertedEmployeeId = Convert.ToInt32(command.ExecuteScalar());

                Console.WriteLine((insertedEmployeeId > 0)?"Employee Added Sucessfully":throw new DatabaseConnectionException("Error: database Connection"));
                return insertedEmployeeId;
            }
            
        }

        List<Employee> IEmployeeService.GetAllEmployees()
        {
            List<Employee> employees = new List<Employee>();
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "SELECT * FROM Employee";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Employee employee = new Employee
                        {
                            EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeId")),
                            FirstName = reader.GetString(reader.GetOrdinal("FirstName")),
                            LastName = reader.GetString(reader.GetOrdinal("LastName")),
                            DateOfBirth = reader.GetDateTime(reader.GetOrdinal("DateOfBirth")),
                            Gender = reader.GetString(reader.GetOrdinal("Gender")),
                            Email = reader.GetString(reader.GetOrdinal("Email")),
                            PhoneNumber = reader.GetString(reader.GetOrdinal("PhoneNumber")),
                            Address = reader.GetString(reader.GetOrdinal("Address")),
                            Position = reader.GetString(reader.GetOrdinal("Position")),
                            JoiningDate = reader.GetDateTime(reader.GetOrdinal("JoiningDate")),
                            TerminationDate = reader.IsDBNull(reader.GetOrdinal("TerminationDate")) ? null : reader.GetDateTime(reader.GetOrdinal("TerminationDate"))
                        };

                        employees.Add(employee);
                    }
                }   
            } 
            PrintEmployeeDetails(employees);
            return employees;
        }

        Employee IEmployeeService.GetEmployeeById(int employeeId)
        {
            Employee employee = null;
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "SELECT * FROM Employee WHERE EmployeeId = @EmployeeId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmployeeId", employeeId);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();//execution starts

                    if (reader.Read())
                    {
                       employee = new Employee
                        {
                            EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeId")),
                            FirstName = reader.GetString(reader.GetOrdinal("FirstName")),
                            LastName = reader.GetString(reader.GetOrdinal("LastName")),
                            DateOfBirth = reader.GetDateTime(reader.GetOrdinal("DateOfBirth")),
                            Gender = reader.GetString(reader.GetOrdinal("Gender")),
                            Email = reader.GetString(reader.GetOrdinal("Email")),
                            PhoneNumber = reader.GetString(reader.GetOrdinal("PhoneNumber")),
                            Address = reader.GetString(reader.GetOrdinal("Address")),
                            Position = reader.GetString(reader.GetOrdinal("Position")),
                            JoiningDate = reader.GetDateTime(reader.GetOrdinal("JoiningDate")),
                            TerminationDate = reader.IsDBNull(reader.GetOrdinal("TerminationDate")) ? null : reader.GetDateTime(reader.GetOrdinal("TerminationDate"))
                        };
                    }
                }
            }
            return employee;
        }
        //To print the details in list to console
        public void PrintEmployeeDetails(List<Employee> employees)
        {
            foreach (var employee in employees)
            {
                Console.WriteLine($"Employee ID: {employee.EmployeeID}\t" +
                                  $"Name: {employee.FirstName} {employee.LastName}\t" +
                                  $"Date of Birth: {employee.DateOfBirth.ToShortDateString()}\t" +
                                  $"Gender: {employee.Gender}\t" +
                                  $"Email: {employee.Email}\t" +
                                  $"Phone Number: {employee.PhoneNumber}\t" +
                                  $"Address: {employee.Address}\t" +
                                  $"Position: {employee.Position}\t" +
                                  $"Joining Date: {employee.JoiningDate.ToShortDateString()}\t" +
                                  $"Termination Date: {(employee.TerminationDate != null ? employee.TerminationDate.Value.ToShortDateString() : "Not terminated")}");
                Console.WriteLine();
            }
        }

        void IEmployeeService.RemoveEmployee(int employeeId)
        {
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "DELETE FROM Employee WHERE EmployeeId = @EmployeeId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmployeeId", employeeId);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        Console.WriteLine($"Employee with ID {employeeId} removed successfully.");
                    }
                    else
                    {
                        throw new EmployeeNotFoundException("Employee Not found in the database");
                    }
                }
            }
        }

        void IEmployeeService.UpdateEmployee(int employeeId, Employee employeeData)
        {
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = @"UPDATE Employee 
                             SET FirstName = @FirstName, 
                                 LastName = @LastName, 
                                 DateOfBirth = @DateOfBirth, 
                                 Gender = @Gender, 
                                 Email = @Email, 
                                 PhoneNumber = @PhoneNumber, 
                                 Address = @Address, 
                                 Position = @Position, 
                                 JoiningDate = @JoiningDate, 
                                 TerminationDate  = @TerminationDate 
                             WHERE EmployeeId = @EmployeeId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FirstName", employeeData.FirstName);
                    command.Parameters.AddWithValue("@LastName", employeeData.LastName);
                    command.Parameters.AddWithValue("@DateOfBirth", employeeData.DateOfBirth);
                    command.Parameters.AddWithValue("@Gender", employeeData.Gender);
                    command.Parameters.AddWithValue("@Email", employeeData.Email);
                    command.Parameters.AddWithValue("@PhoneNumber", employeeData.PhoneNumber);
                    command.Parameters.AddWithValue("@Address", employeeData.Address);
                    command.Parameters.AddWithValue("@Position", employeeData.Position);
                    command.Parameters.AddWithValue("@JoiningDate", employeeData.JoiningDate);
                    command.Parameters.AddWithValue("@TerminationDate", (object)employeeData.TerminationDate ?? DBNull.Value);
                    command.Parameters.AddWithValue("@EmployeeId", employeeId);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        Console.WriteLine($"Employee with ID {employeeId} updated successfully.");
                    }
                    else
                    {
                        throw new EmployeeNotFoundException("Employee Not found in the database");
                    }
                }
            }
        }

        public void PrintEmployeeDetail(Employee employee)
        {
            if (employee != null)
            {
                Console.WriteLine($"Employee ID: {employee.EmployeeID}\t" +
                                  $"First Name: {employee.FirstName}\t" +
                                  $"Last Name: {employee.LastName}\t" +
                                  $"Date of Birth: {employee.DateOfBirth.ToShortDateString()}\t" +
                                  $"Gender: {employee.Gender}\t" +
                                  $"Email: {employee.Email}\t" +
                                  $"Phone Number: {employee.PhoneNumber}\t" +
                                  $"Address: {employee.Address}\t" +
                                  $"Position: {employee.Position}\t" +
                                  $"Joining Date: {employee.JoiningDate.ToShortDateString()}\t" +
                                  $"Termination Date: {(employee.TerminationDate != null ? employee.TerminationDate.Value.ToShortDateString() : "Not terminated")}");
            }
            else
            {
                throw new EmployeeNotFoundException("Employee Not found in the database");
            }
        }

        public void GetEmployeeById(int employeeId)
        {
            throw new NotImplementedException();
        }
    }
    
}
