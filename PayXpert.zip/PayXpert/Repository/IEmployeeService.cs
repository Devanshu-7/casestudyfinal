﻿using PayXpert.Models;

namespace PayXpert.Repository
{
    public interface IEmployeeService
    {
        Employee GetEmployeeById(int employeeId);
        List<Employee> GetAllEmployees();
        int AddEmployee(Employee employeeData);
        void UpdateEmployee(int employeeId, Employee employeeData);
        void RemoveEmployee(int employeeId);
    }
}
