﻿using PayXpert.Exceptions;
using PayXpert.Models;
using PayXpert.Utility;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayXpert.Repository
{
    public class TaxRepository : ITaxService
    {
        void ITaxService.CalculateTax(int employeeId, int taxYear)
        {
            
            decimal taxableIncome = GetTaxableIncome(employeeId, taxYear);

            decimal taxAmount = taxableIncome * .12m; 

            Console.WriteLine($"The Tax Amount for Employee ID: {employeeId} on the year {taxYear} = {taxAmount}");


        }


        private decimal GetTaxableIncome(int employeeId, int taxYear)
        {
            //initialize value
            decimal taxableIncome = -1;
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "SELECT TaxableIncome FROM Tax WHERE EmployeeId = @EmployeeId AND TaxYear = @TaxYear";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmployeeId", employeeId);
                    command.Parameters.AddWithValue("@TaxYear", taxYear);

                    connection.Open();
                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        taxableIncome = Convert.ToDecimal(result);
                    }
                    else
                    {
                        throw new TaxCalculationException("Tax year and employee mismatch");
                    }
                }
            }
            return taxableIncome;
        }

        Tax ITaxService.GetTaxById(int taxId)
        {
            Tax tax = null;
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "SELECT * FROM Tax WHERE TaxId = @TaxId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TaxId", taxId);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        tax = new Tax
                        {
                            TaxID = reader.GetInt32(reader.GetOrdinal("TaxID")),
                            EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeID")),
                            TaxYear = reader.GetInt32(reader.GetOrdinal("TaxYear")),
                            TaxableIncome = reader.GetDecimal(reader.GetOrdinal("TaxableIncome")),
                            TaxAmount = reader.GetDecimal(reader.GetOrdinal("TaxAmount"))
                        };
                    }
                }
            }
            return tax;
        }

        List<Tax> ITaxService.GetTaxesForEmployee(int employeeId)
        {
            List<Tax> taxes = new List<Tax>();
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "SELECT * FROM Tax WHERE EmployeeId = @EmployeeId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmployeeId", employeeId);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Tax tax = new Tax
                        {
                            TaxID = reader.GetInt32(reader.GetOrdinal("TaxID")),
                            EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeID")),
                            TaxYear = reader.GetInt32(reader.GetOrdinal("TaxYear")),
                            TaxableIncome = reader.GetDecimal(reader.GetOrdinal("TaxableIncome")),
                            TaxAmount = reader.GetDecimal(reader.GetOrdinal("TaxAmount"))
                        };
                        taxes.Add(tax);
                    }
                }
            }
            PrintTaxList(taxes);
            return taxes;
        }

        List<Tax> ITaxService.GetTaxesForYear(int taxYear)
        {
            List<Tax> taxes = new List<Tax>();
            using (SqlConnection connection = new SqlConnection(DBUtil.GetConnectionString()))
            {
                string query = "SELECT * FROM Tax WHERE TaxYear = @TaxYear";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TaxYear", taxYear);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Tax tax = new Tax
                        {
                            TaxID = reader.GetInt32(reader.GetOrdinal("TaxID")),
                            EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeID")),
                            TaxYear = reader.GetInt32(reader.GetOrdinal("TaxYear")),
                            TaxableIncome = reader.GetDecimal(reader.GetOrdinal("TaxableIncome")),
                            TaxAmount = reader.GetDecimal(reader.GetOrdinal("TaxAmount"))
                        };
                        taxes.Add(tax);
                    }
                }
            }
            PrintTaxList(taxes);
            return taxes;
        }

        public void PrintTaxList(List<Tax> taxes)
        {
            if (taxes == null || taxes.Count == 0)
            {
                Console.WriteLine("No tax records found.");
                return;
            }

            Console.WriteLine("Tax Details:");
            foreach (var tax in taxes)
            {
                Console.WriteLine($"Tax ID: {tax.TaxID} ||| Employee ID: {tax.EmployeeID} ||| Tax Year: {tax.TaxYear} ||| Taxable Income: {tax.TaxableIncome} ||| Tax Amount: {tax.TaxAmount}");
                
            }
        }
    }
}
 
