﻿using PayXpert.Exceptions;
using PayXpert.Models;
using PayXpert.Repository;
using PayXpert.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayXpert.App
{
    public class PayrollSystem
    {
        private readonly EmployeeService _employeeService;
        private readonly FinancialRecordService _financialRecordService;
        private readonly PayRollService _payRollService;
        private readonly TaxService _taxService;

        public PayrollSystem(EmployeeService employeeService, FinancialRecordService financialRecordService, PayRollService payRollService, TaxService taxService)
        {
            _employeeService = employeeService;
            _financialRecordService = financialRecordService;
            _payRollService = payRollService;
            _taxService = taxService;
        }


        public void Run() { 
        
        bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\t\t#. Welcome to PayRoll Management System");
                Console.WriteLine("\t\t1. Authorization as Admin");
                Console.WriteLine("\t\t2. Authorization as Employee");
                Console.WriteLine("\t\t3. Exit Application");
                Console.Write("Please enter your choice: ");
                string selectit = Console.ReadLine();
                switch (selectit)
                {
                    case "1":
                        basemenu();
                        break;
                    case "2":
                        Console.WriteLine("You are just an employee, You Need Admin Authorization for access");
                        break;
                    case "3":
                        Console.WriteLine("Exiting.....");
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please Choose between 1-3.");
                        break;

                }
            }
        }
        private void basemenu()
        {
            bool exit = false;

            while (!exit)
            {
                
                Console.WriteLine("\t\tLets look at the key Functionalities it offers");
                Console.WriteLine("\t\t1. Employee Management");
                Console.WriteLine("\t\t2. Payroll Processing");
                Console.WriteLine("\t\t3. Tax Calculation");
                Console.WriteLine("\t\t4. Financial Reporting");
                Console.WriteLine("\t\t5. Exit");
                Console.WriteLine();
                Console.Write("Please enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        EmployeeManagementMenu();
                        break;
                    case "2":
                        PayrollProcessingMenu();
                        break;
                    case "3":
                        TaxCalculationMenu();
                        break;
                    case "4":
                        FinancialReportingMenu();
                        break;
                    case "5":
                        Console.WriteLine("Exiting.....");
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please Choose between 1-5.");
                        break;
                }
                Console.WriteLine();
            }
        }

        private void FinancialReportingMenu()
        {
            bool exit = false;
            do
            {
                Console.WriteLine("#. Financial Reporting Menu");
                Console.WriteLine("1. Add Financial Record");
                Console.WriteLine("2. Get Financial Record by ID");
                Console.WriteLine("3. Get Financial Records for Employee");
                Console.WriteLine("4. Get Financial Records for Date");
                Console.WriteLine("5. Back to Main Menu");

                Console.Write("Please enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        _financialRecordService.AddFinancialRecord();
                        break;
                    case "2":
                        _financialRecordService.GetFinancialRecordById();
                        break;
                    case "3":
                        _financialRecordService.GetFinancialRecordsForEmployee();
                        break;
                    case "4":
                        _financialRecordService.GetFinancialRecordsForDate();
                        break;
                    case "5":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again. Please Choose Between 1-5 ");
                        break;
                }

                Console.WriteLine();
            } while (!exit);
        }

       

        private void TaxCalculationMenu()
        {
        bool exit = false;
        do
        {
            Console.WriteLine("#  Tax Calculation Menu");
            Console.WriteLine("1. Calculate Tax");
            Console.WriteLine("2. Get Tax by ID");
            Console.WriteLine("3. Get Taxes for Employee");
            Console.WriteLine("4. Get Taxes for Year");
            Console.WriteLine("5. Back to Main Menu");

            Console.Write("Please enter your choice: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    _taxService.CalculateTax();
                    break;
                case "2":
                    _taxService.GetTaxById();
                    break;
                case "3":
                    _taxService.GetTaxesForEmployee();
                    break;
                case "4":
                    _taxService.GetTaxesForYear();
                    break;
                case "5":
                    exit = true; 
                    break;
                default:
                    Console.WriteLine("Please Choose Between 1-5, Invalid choice. Please try again.");
                    break;
            }

            Console.WriteLine();
        } while (!exit);
    }

       

        private void PayrollProcessingMenu()
        {
            bool exit = false;
            do
            {
                Console.WriteLine("#  Payroll Processing Menu");
                Console.WriteLine("1. Generate Payroll");
                Console.WriteLine("2. Get Payroll by ID");
                Console.WriteLine("3. Get Payrolls for Employee");
                Console.WriteLine("4. Get Payrolls for Period");
                Console.WriteLine("5. Back to Main Menu");

                Console.Write("Please enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
     {
                    case "1":
                        _payRollService.GeneratePayroll();
                        break;
                    case "2":
                        _payRollService.GetPayrollById();
                        break;
                    case "3":
                        _payRollService.GetPayrollsForEmployee();
                        break;
                    case "4":
                         _payRollService.GetPayrollsForPeriod();
                        break;
                    case "5":
                        exit = true; 
                        break;
                    default:
                        Console.WriteLine("Please Choose Between 1-5, Invalid choice. Please try again.");
                        break;
                }

                Console.WriteLine();
            } while (!exit);
        }

       

        private void EmployeeManagementMenu()
        {
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("#  Employee Management Menu");
                Console.WriteLine("1. Get Employee by ID");
                Console.WriteLine("2. Get All Employees");
                Console.WriteLine("3. Add Employee");
                Console.WriteLine("4. Update Employee");
                Console.WriteLine("5. Remove Employee");
                Console.WriteLine("6. Back to Main Menu");

                Console.Write("Please enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        _employeeService.GetEmployeeById();
                        break;
                    case "2":
                       _employeeService.GetAllEmployees();
                        break;
                    case "3":
                        int employeeId = _employeeService.AddEmployee();
                        Console.WriteLine($"The Column To Which Data Has been Added is {employeeId}");
                        break;
                    case "4":
                        _employeeService.UpdateEmployee();
                        break;
                    case "5":
                        _employeeService.RemoveEmployee();
                        Console.WriteLine("Employee Removed");
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again. PLease Choose BEtween 1-6 ");
                        break;
                }

                Console.WriteLine();
            }
        }
    }
}
