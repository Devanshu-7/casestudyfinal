﻿using PayXpert.App;
using PayXpert.Repository;
using PayXpert.Services;

namespace PayXpert
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IEmployeeService employeeRepository = new EmployeeRepository();
            IPayrollService payrollRepository = new PayrollRepository();
            IFinancialRecordService financialRecordRepository = new FinancialRecordRepository();
            ITaxService taxRepository = new TaxRepository();

            EmployeeService employeeService = new EmployeeService(employeeRepository);
            FinancialRecordService financialRecordService = new FinancialRecordService(financialRecordRepository);
            PayRollService payRollService = new PayRollService(payrollRepository);
            TaxService taxService = new TaxService(taxRepository);

            // Initialize the PayrollSystem class with the services
            PayrollSystem payrollSystem = new PayrollSystem(employeeService, financialRecordService, payRollService, taxService);
            payrollSystem.Run();


        }
    }
}
